package Excepciones;

public class FolderIsNotEmptyException extends Exception {
    
}