package Excepciones;

public class FileAlreadyExistsException extends Exception {
    
}