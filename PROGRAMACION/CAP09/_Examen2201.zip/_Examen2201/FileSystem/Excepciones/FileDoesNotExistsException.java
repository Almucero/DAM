package Excepciones;

public class FileDoesNotExistsException extends Exception {
    
}