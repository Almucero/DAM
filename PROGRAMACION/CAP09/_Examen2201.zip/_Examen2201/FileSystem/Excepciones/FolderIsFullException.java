package Excepciones;

public class FolderIsFullException extends Exception {
    
}